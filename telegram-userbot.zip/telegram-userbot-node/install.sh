#!/bin/bash

set -e

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${GREEN}"
echo "╔══════════════════════════════════════╗"
echo "║   Telegram Userbot - Auto Installer  ║"
echo "╚══════════════════════════════════════╝"
echo -e "${NC}"

# ── Cek Node.js ──────────────────────────────────────────
if ! command -v node &> /dev/null; then
  echo -e "${RED}[ERROR] Node.js tidak ditemukan. Install dulu: https://nodejs.org${NC}"
  exit 1
fi
NODE_MAJOR=$(node -e "console.log(parseInt(process.versions.node.split('.')[0]))")
if [ "$NODE_MAJOR" -lt 16 ]; then
  echo -e "${RED}[ERROR] Node.js minimal v16. Versi kamu: $(node -v)${NC}"
  exit 1
fi
echo -e "${GREEN}[OK] Node.js $(node -v)${NC}"

# ── Cek npm ──────────────────────────────────────────────
if ! command -v npm &> /dev/null; then
  echo -e "${RED}[ERROR] npm tidak ditemukan.${NC}"
  exit 1
fi
echo -e "${GREEN}[OK] npm $(npm -v)${NC}"

# ── Cek index.js ─────────────────────────────────────────
if [ ! -f "index.js" ]; then
  echo -e "${RED}[ERROR] index.js tidak ditemukan di folder ini.${NC}"
  exit 1
fi
echo -e "${GREEN}[OK] index.js ditemukan.${NC}"

# ── Install dependencies ──────────────────────────────────
echo ""
echo -e "${YELLOW}[INSTALL] Menginstall dependencies...${NC}"
npm install --omit=dev
echo -e "${GREEN}[OK] Dependencies terinstall.${NC}"

# ── Setup config.json ─────────────────────────────────────
if [ -f "config.json" ]; then
  echo -e "${YELLOW}[SKIP] config.json sudah ada, tidak ditimpa.${NC}"
else
  echo ""
  echo -e "${YELLOW}══════════════════════════════════════${NC}"
  echo -e "${YELLOW}   SETUP KONFIGURASI${NC}"
  echo -e "${YELLOW}══════════════════════════════════════${NC}"
  echo ""
  echo "  Ambil API ID & Hash dari https://my.telegram.org"
  echo ""

  read -p "  API ID              : " API_ID
  read -p "  API Hash            : " API_HASH
  read -p "  Nomor HP (+62...)   : " PHONE
  read -p "  Session name        [userbot_session]: " SESSION
  SESSION=${SESSION:-userbot_session}
  read -p "  Password 2FA        (kosongkan jika tidak ada): " PASSWORD
  echo ""
  read -p "  API Key QRIS        (kosongkan jika tidak pakai): " API_KEY
  echo ""
  echo -e "${YELLOW}  Keyword pertama (bisa tambah lagi via .kw add):${NC}"
  read -p "  Alias (pisah koma)  : " KW_ALIAS
  read -p "  Balasan             : " KW_REPLY

  # Format alias jadi JSON array
  KW_JSON=$(echo "$KW_ALIAS" | tr ',' '\n' | sed 's/^[[:space:]]*//' | sed 's/[[:space:]]*$//' | sed 's/.*/"&"/' | paste -sd ',' -)

  cat > config.json << CFGEOF
{
  "api_id": ${API_ID},
  "api_hash": "${API_HASH}",
  "phone": "${PHONE}",
  "session_name": "${SESSION}",
  "password": "${PASSWORD}",

  "keywords": [
    {
      "aliases": [${KW_JSON}],
      "reply": "${KW_REPLY}"
    }
  ],
  "blacklist": [],
  "pm": {
    "enabled": true,
    "message": "Halo! Saya sedang sibuk, akan segera balas \ud83d\ude4f",
    "cooldown_seconds": 300
  },

  "match_mode": "contains",
  "case_sensitive": false,
  "cooldown_seconds": 30,
  "only_first_match": true,
  "quote_reply": true,
  "poll_interval": 3,

  "autoReply": true,
  "pmReply": true,
  "broadcast": null,

  "API_KEY": "${API_KEY}",
  "API_CREATE_URL": "https://tokoshopp.web.id/api/payment/create",
  "API_STATUS_URL": "https://tokoshopp.web.id/api/payment/status",
  "STATUS_INTERVAL": 5000,
  "STATUS_TIMEOUT": 1800000
}
CFGEOF

  # Validasi JSON
  if node -e "JSON.parse(require('fs').readFileSync('config.json','utf-8'))" 2>/dev/null; then
    echo -e "${GREEN}[OK] config.json dibuat dan valid.${NC}"
  else
    echo -e "${RED}[WARN] config.json mungkin ada karakter khusus yang bermasalah."
    echo -e "       Edit manual jika ada error saat start.${NC}"
  fi
fi

# ── Done ─────────────────────────────────────────────────
echo ""
echo -e "${GREEN}╔══════════════════════════════════════╗${NC}"
echo -e "${GREEN}║   Instalasi selesai!                 ║${NC}"
echo -e "${GREEN}║                                      ║${NC}"
echo -e "${GREEN}║   Jalankan: npm start                ║${NC}"
echo -e "${GREEN}║                                      ║${NC}"
echo -e "${GREEN}║   Login pertama kali:                ║${NC}"
echo -e "${GREEN}║   - Masukkan kode OTP dari Telegram  ║${NC}"
echo -e "${GREEN}║                                      ║${NC}"
echo -e "${GREEN}║   Kontrol via Saved Messages:        ║${NC}"
echo -e "${GREEN}║   .menu  .ar on/off  .pm on/off      ║${NC}"
echo -e "${GREEN}║   .kw add alias | balas              ║${NC}"
echo -e "${GREEN}║   .qris {nominal}  .cal {expr}       ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════╝${NC}"
echo ""

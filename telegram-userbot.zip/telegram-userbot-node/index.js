/**
 * index.js — Telegram Userbot All-in-One
 * ========================================
 * Fitur:
 *  - Auto-reply keyword dari post channel di grup diskusi
 *  - Auto-reply PM
 *  - .cal {ekspresi}  → kalkulator
 *  - .qris {nominal}  → generate QRIS + auto-monitoring pembayaran
 *  - .done            → selesaikan invoice manual
 *  - Panel kontrol via Saved Messages: !ar on/off, !pm on/off, !kw, !bl, !bc, !menu
 *
 * Jalankan: node index.js
 */
"use strict";

const fs       = require("fs");
const path     = require("path");
const readline = require("readline");
const https    = require("https");
const http     = require("http");
const os       = require("os");
const crypto   = require("crypto");

const { TelegramClient } = require("telegram");
const { StringSession }  = require("telegram/sessions");
const { NewMessage }     = require("telegram/events");

const CONFIG_PATH = path.join(__dirname, "config.json");

// ──────────────────────────────────────────────────────────
// CONFIG
// ──────────────────────────────────────────────────────────

function loadConfig() {
  const c = JSON.parse(fs.readFileSync(CONFIG_PATH, "utf-8"));
  if (!c.blacklist)  c.blacklist  = [];
  if (!c.pm)         c.pm         = { enabled: true, message: "Halo! Saya sedang sibuk 🙏", cooldown_seconds: 300 };
  if (c.autoReply  === undefined) c.autoReply  = true;
  if (c.pmReply    === undefined) c.pmReply    = true;
  if (!c.broadcast)  c.broadcast  = null;
  // QRIS config dengan fallback
  if (!c.API_CREATE_URL) c.API_CREATE_URL = "https://tokoshopp.web.id/api/payment/create";
  if (!c.API_STATUS_URL) c.API_STATUS_URL = "https://tokoshopp.web.id/api/payment/status";
  if (!c.STATUS_INTERVAL) c.STATUS_INTERVAL = 5000;
  if (!c.STATUS_TIMEOUT)  c.STATUS_TIMEOUT  = 1800000;
  return c;
}
function saveConfig(c) { fs.writeFileSync(CONFIG_PATH, JSON.stringify(c, null, 2), "utf-8"); }

// ──────────────────────────────────────────────────────────
// HELPER INPUT
// ──────────────────────────────────────────────────────────

function createRL() { return readline.createInterface({ input: process.stdin, output: process.stdout }); }
function question(rl, p) { return new Promise(r => rl.question(p, a => r(a.trim()))); }
async function ask(rl, p, d = null) {
  const suf = d != null ? ` [${d}]` : "";
  while (true) {
    const v = await question(rl, `${p}${suf}: `);
    if (!v && d != null) return d;
    if (v) return v;
    console.log("  -> Wajib diisi.");
  }
}
async function askYN(rl, p, d = true) {
  const v = (await question(rl, `${p} (${d?"Y/n":"y/N"}): `)).toLowerCase();
  return !v ? d : v === "y" || v === "ya";
}
async function askInt(rl, p, d) {
  const v = await question(rl, `${p} [${d}]: `);
  if (!v) return d;
  const n = parseInt(v, 10);
  return isNaN(n) ? d : n;
}
function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

// ──────────────────────────────────────────────────────────
// SETUP WIZARD
// ──────────────────────────────────────────────────────────

async function runSetupWizard() {
  console.log("=".repeat(55));
  console.log(" SETUP WIZARD");
  console.log("=".repeat(55) + "\n");
  const rl = createRL();

  // ── Step 1: Kredensial ──
  console.log("Ambil API ID & Hash di https://my.telegram.org\n");
  let apiId = await askInt(rl, "API ID", 0);
  while (!apiId) apiId = await askInt(rl, "API ID (wajib, bukan 0)", 0);
  const apiHash = await ask(rl, "API Hash");
  const phone   = await ask(rl, "Nomor telepon (+62...)");
  const session = await ask(rl, "Nama file session", "userbot_session");

  // ── Step 2: QRIS ──
  console.log("\n--- QRIS API ---");
  console.log("Kosongkan kalau tidak pakai fitur QRIS.\n");
  const apiKey = await ask(rl, "API Key", "");

  // ── Step 3: Auto Reply PM ──
  console.log("\n--- Auto Reply PM ---");
  const pmEnabled  = await askYN(rl, "Aktifkan auto reply PM?", true);
  const pmMsg      = pmEnabled ? await ask(rl, "Pesan balasan PM", "Halo! Saya sedang sibuk, akan segera balas 🙏") : "Halo! Saya sedang sibuk 🙏";
  const pmCooldown = pmEnabled ? await askInt(rl, "Cooldown per user (detik, 0 = selalu balas)", 300) : 300;

  // ── Step 4: Keyword ──
  console.log("\n--- Keyword & Balasan ---");
  console.log("Alias bisa lebih dari satu, pisah koma. Contoh: harga,price,berapa\n");
  const keywords = []; let idx = 1;
  while (true) {
    console.log(`  Keyword #${idx} (ketik 'selesai' untuk selesai)`);
    const kw = await ask(rl, "  Keyword alias (pisah koma)", null, false);
    if (!kw || kw.toLowerCase() === "selesai") {
      if (!keywords.length) { console.log("  Minimal 1 keyword.\n"); continue; }
      break;
    }
    const rep = await ask(rl, "  Balasan");
    keywords.push({ aliases: kw.split(",").map(k => k.trim().toLowerCase()).filter(Boolean), reply: rep });
    console.log();
    idx++;
  }

  // ── Step 5: Opsi lanjutan ──
  console.log("\n--- Opsi Lanjutan ---");
  let matchMode = await ask(rl, "Mode cocok: 'contains' (mengandung kata) / 'exact' (kata utuh)", "contains");
  if (!["contains","exact"].includes(matchMode)) matchMode = "contains";
  const cooldown       = await askInt(rl, "Cooldown reply post channel yang sama (detik)", 30);
  const onlyFirst      = await askYN(rl, "Hanya reply keyword pertama yang cocok?", true);
  const quoteReply     = await askYN(rl, "Reply sebagai quote ke post channel?", true);
  const pollInterval   = await askInt(rl, "Interval polling pesan baru (detik)", 3);

  const config = {
    api_id: apiId, api_hash: apiHash, phone, session_name: session,
    API_KEY: apiKey,
    API_CREATE_URL: "https://tokoshopp.web.id/api/payment/create",
    API_STATUS_URL: "https://tokoshopp.web.id/api/payment/status",
    STATUS_INTERVAL: 5000,
    STATUS_TIMEOUT: 1800000,
    keywords, blacklist: [],
    pm: { enabled: pmEnabled, message: pmMsg, cooldown_seconds: pmCooldown },
    match_mode: matchMode, case_sensitive: false,
    cooldown_seconds: cooldown,
    only_first_match: onlyFirst,
    quote_reply: quoteReply,
    poll_interval: pollInterval,
    autoReply: true, pmReply: pmEnabled, broadcast: null,
  };
  rl.close();
  saveConfig(config);
  console.log("\n✅ Konfigurasi tersimpan di config.json\n");
  return config;
}

// ──────────────────────────────────────────────────────────
// MATCHING
// ──────────────────────────────────────────────────────────

function isBlacklisted(text, blacklist, cs) {
  if (!blacklist?.length) return false;
  const hay = cs ? text : text.toLowerCase();
  return blacklist.some(w => hay.includes(cs ? w : w.toLowerCase()));
}
function findReply(text, keywords, mode, cs, onlyFirst) {
  if (!text) return null;
  const hay = cs ? text : text.toLowerCase();
  const out = [];
  for (const kw of keywords) {
    for (const alias of kw.aliases) {
      const n = cs ? alias : alias.toLowerCase();
      const found = mode === "exact" ? hay.split(/\s+/).includes(n) : hay.includes(n);
      if (found) { out.push(kw.reply); break; }
    }
  }
  return out.length ? (onlyFirst ? out[0] : out.join("\n")) : null;
}

// ──────────────────────────────────────────────────────────
// SESSION
// ──────────────────────────────────────────────────────────

function sessionPath(name) { return path.join(__dirname, `${name}.session`); }
function loadSession(name) {
  const p = sessionPath(name);
  if (!fs.existsSync(p)) return undefined;
  const s = fs.readFileSync(p, "utf-8").trim();
  return s.length ? s : undefined;
}
function saveSession(name, str) { fs.writeFileSync(sessionPath(name), str, "utf-8"); }

// ──────────────────────────────────────────────────────────
// HTTP HELPER
// ──────────────────────────────────────────────────────────

function httpPost(url, body, headers = {}, timeoutMs = 15000) {
  return new Promise((resolve, reject) => {
    const parsed  = new URL(url);
    const data    = JSON.stringify(body);
    const lib     = parsed.protocol === "https:" ? https : http;
    const options = {
      hostname: parsed.hostname,
      port: parsed.port || (parsed.protocol === "https:" ? 443 : 80),
      path: parsed.pathname + parsed.search,
      method: "POST",
      headers: { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(data), ...headers },
    };
    const req = lib.request(options, res => {
      let raw = "";
      res.on("data", chunk => raw += chunk);
      res.on("end", () => {
        try { resolve(JSON.parse(raw)); }
        catch { reject(new Error("Response bukan JSON: " + raw.slice(0, 100))); }
      });
    });
    req.setTimeout(timeoutMs, () => { req.destroy(); reject(new Error("API timeout")); });
    req.on("error", reject);
    req.write(data);
    req.end();
  });
}

// ──────────────────────────────────────────────────────────
// MENU TEXT (Saved Messages panel)
// ──────────────────────────────────────────────────────────

function buildMenu(cfg) {
  const dot = v => v ? "●" : "○";
  const bc  = cfg.broadcast ? `tiap ${cfg.broadcast.intervalSec}s` : "off";
  return (
    `📡 *Panel Kontrol*\n\n` +
    `${dot(cfg.autoReply)} AR Channel   ${dot(cfg.pmReply)} AR PM\n` +
    `📢 Broadcast : ${bc}\n` +
    `🔑 ${cfg.keywords.length} keyword   🚫 ${cfg.blacklist.length} blacklist\n\n` +
    `*— Panel CMD —*\n` +
    `.ar on/off         → toggle AR channel\n` +
    `.ar pm on/off      → toggle AR PM\n` +
    `.pm msg {teks}     → ubah pesan PM\n` +
    `.pm cd {detik}     → cooldown PM\n` +
    `.kw list           → list keyword\n` +
    `.kw add {a,b} | {balas}\n` +
    `.kw del {n}\n` +
    `.bl list/add/del   → kelola blacklist\n` +
    `.bc {pesan} | {dtk?} → broadcast\n` +
    `.bc stop\n` +
    `.status / .menu\n\n` +
    `*— Userbot CMD —*\n` +
    `.cal {ekspresi}    → kalkulator\n` +
    `.qris {nominal}    → generate QRIS\n` +
    `.done              → selesaikan invoice`
  );
}

function buildStatus(cfg) {
  const ar = cfg.autoReply ? "🟢 ON" : "🔴 OFF";
  const pm = cfg.pmReply   ? "🟢 ON" : "🔴 OFF";
  const bc = cfg.broadcast ? `🔁 ${cfg.broadcast.intervalSec}s` : "off";
  return (
    `📊 *Status Bot*\n\n` +
    `📨 AR Channel : ${ar}\n` +
    `💬 AR PM      : ${pm}\n` +
    `📢 Broadcast  : ${bc}\n` +
    `🔑 Keywords   : ${cfg.keywords.length}\n` +
    `🚫 Blacklist  : ${cfg.blacklist.length} kata`
  );
}

// ──────────────────────────────────────────────────────────
// USERBOT CLASS
// ──────────────────────────────────────────────────────────

class Userbot {
  constructor() {
    this.config      = loadConfig();
    this.seenMsgIds  = new Map();
    this.lastReply   = new Map();
    this.pmLastReply = new Map();
    this.bcTimer     = null;
    this.myId        = null;
    // QRIS: Map chatId -> { orderId, transactionId, amount, msgId, monitorTimer }
    this.activeInvoices = new Map();
  }

  reload() { this.config = loadConfig(); }

  cooldownOk(map, key, ms) {
    const last = map.get(key) || 0;
    if (Date.now() - last < ms) return false;
    map.set(key, Date.now()); return true;
  }

  isChannelPost(msg) {
    // Hanya pesan yang di-forward dari channel (post channel di grup diskusi)
    const fwd = msg.fwdFrom;
    if (!fwd) return false;
    // fromId harus PeerChannel (bukan PeerUser/PeerChat)
    return fwd.fromId?.className === "PeerChannel";
  }
  isPrivateMsg(msg)  { return msg.peerId?.className === "PeerUser"; }
  isSavedMessages(event) {
    if (!this.myId) return false;
    const cid = event.chatId ? BigInt(event.chatId).toString() : null;
    const mid = BigInt(this.myId).toString();
    return cid === mid;
  }

  // ── Grup diskusi ────────────────────────────────────
  async getGroups() {
    try {
      const d = await this.client.getDialogs({ limit: 200 });
      return d.filter(x => x.entity?.className === "Channel" && x.entity?.megagroup).map(x => x.id);
    } catch { return []; }
  }

  // ── Broadcast sync ──────────────────────────────────
  syncBroadcast() {
    if (this.bcTimer) { clearInterval(this.bcTimer); this.bcTimer = null; }
    const bc = this.config.broadcast;
    if (!bc?.intervalSec) return;
    this.bcTimer = setInterval(() => this.doBroadcast(bc.text), bc.intervalSec * 1000);
    console.log(`[BC] Aktif tiap ${bc.intervalSec}s`);
  }

  async doBroadcast(text) {
    const groups = await this.getGroups();
    let sent = 0, fail = 0;
    for (const id of groups) {
      try { await this.client.sendMessage(id, { message: text }); sent++; await sleep(1500); }
      catch { fail++; }
    }
    console.log(`[BC] sent=${sent} fail=${fail}`);
  }

  // ── Polling channel ─────────────────────────────────
  async startPolling() {
    const ms = (this.config.poll_interval || 3) * 1000;
    const groups = await this.getGroups();
    console.log(`[POLL] ${groups.length} grup, interval ${this.config.poll_interval || 3}s`);
    for (const id of groups) {
      try {
        const msgs = await this.client.getMessages(id, { limit: 5 });
        this.seenMsgIds.set(id.toString(), new Set(msgs.map(m => m.id)));
      } catch (_) {}
    }
    while (true) {
      await sleep(ms);
      this.reload();
      if (!this.config.autoReply) continue;
      for (const id of await this.getGroups()) {
        try { await this.pollChat(id); }
        catch (e) { console.log(`[POLL ERR] ${e.message}`); }
      }
    }
  }

  async pollChat(chatId) {
    const key  = chatId.toString();
    const seen = this.seenMsgIds.get(key) || new Set();
    const msgs = await this.client.getMessages(chatId, { limit: 10 });
    for (const m of msgs.filter(m => !seen.has(m.id)).reverse()) {
      seen.add(m.id);
      await this.processChannelMsg(chatId, m);
    }
    if (seen.size > 200) {
      const arr = [...seen]; this.seenMsgIds.set(key, new Set(arr.slice(-200)));
    } else { this.seenMsgIds.set(key, seen); }
  }

  async processChannelMsg(chatId, msg) {
    if (!this.isChannelPost(msg)) return;
    if (!this.cooldownOk(this.lastReply, `${chatId}:${msg.id}`, (this.config.cooldown_seconds || 30) * 1000)) return;
    const text = msg.message || "";
    if (isBlacklisted(text, this.config.blacklist, this.config.case_sensitive)) return;
    const rep = findReply(text, this.config.keywords, this.config.match_mode || "contains",
      this.config.case_sensitive || false, this.config.only_first_match !== false);
    if (!rep) return;
    console.log(`[MATCH] chat=${chatId} post=${msg.id}`);
    try {
      await this.client.sendMessage(chatId, {
        message: rep,
        ...(this.config.quote_reply !== false ? { replyTo: msg.id } : {}),
      });
    } catch (e) { console.log(`[SEND ERR] ${e.message}`); }
  }

  // ── Handler utama semua pesan ───────────────────────
  async handleMessage(event) {
    const msg  = event.message;
    if (!msg) return;
    const text  = (msg.message || "").trim();
    const lower = text.toLowerCase();

    // Saved Messages: handle semua pesan di sini (out bisa false di GramJS)
    if (this.isSavedMessages(event)) {
      if (lower.startsWith(".")) {
        console.log(`[PANEL] ${text.slice(0,60)}`);
        await this.handlePanelCommand(event, text);
      }
      return;
    }

    // Command dari akun sendiri (out=true ATAU senderId === myId)
    const isOwn = msg.out || (msg.senderId && this.myId && BigInt(msg.senderId).toString() === BigInt(this.myId).toString());
    if (isOwn) {
      if (lower.startsWith(".cal "))  { await this.handleCal(event, text); return; }
      if (lower.startsWith(".qris ")) { await this.handleQris(event, text); return; }
      if (lower === ".done")          { await this.handleDone(event); return; }
      return;
    }

    // PM masuk dari orang lain
    if (this.isPrivateMsg(msg)) {
      await this.handlePM(event);
    }
  }

  // ── PM auto-reply ───────────────────────────────────
  async handlePM(event) {
    const msg = event.message;
    this.reload();
    if (!this.config.pmReply || !this.config.pm.enabled) return;
    const uid = msg.senderId?.toString() || msg.peerId?.userId?.toString() || event.chatId?.toString();
    if (!uid || uid === this.myId?.toString()) return;
    const cdMs = (this.config.pm.cooldown_seconds || 0) * 1000;
    if (cdMs > 0 && !this.cooldownOk(this.pmLastReply, uid, cdMs)) return;
    console.log(`[PM] Auto-reply ke uid=${uid}`);
    try {
      await this.client.sendMessage(msg.peerId, { message: this.config.pm.message, replyTo: msg.id });
    } catch (e) { console.log(`[PM ERR] ${e.message}`); }
  }

  // ── Kalkulator ──────────────────────────────────────
  async handleCal(event, text) {
    const expr = text.slice(5).trim();
    if (!expr) return;
    let result;
    try {
      if (!/^[0-9+\-*/%.() \t]+$/.test(expr)) {
        result = "⚠️ Karakter tidak valid. Gunakan: + - * / % ( )";
      } else {
        const val = new Function("return " + expr)();
        if (typeof val !== "number" || !isFinite(val)) throw new Error("Hasil tidak valid");
        result = parseFloat(val.toPrecision(12)).toString();
      }
    } catch (e) { result = "⚠️ Error: " + e.message; }
    try {
      await this.client.sendMessage(event.message.peerId, {
        message: `🧮 ${expr} = *${result}*`,
        replyTo: event.message.id,
      });
    } catch (e) { console.log(`[CAL ERR] ${e.message}`); }
  }

  // ── QRIS ────────────────────────────────────────────
  async handleQris(event, text) {
    const msg    = event.message;
    const chatId = event.chatId?.toString() || msg.peerId?.toString();
    const amountStr = text.slice(6).trim().replace(/[^0-9]/g, "");
    const amount    = parseInt(amountStr, 10);

    if (!amount || amount < 1) {
      try { await this.client.sendMessage(msg.peerId, { message: "⚠️ Nominal tidak valid.\nContoh: `.qris 10000`", replyTo: msg.id }); } catch (_) {}
      return;
    }

    // Cek invoice aktif di chat ini
    if (this.activeInvoices.has(chatId)) {
      const inv = this.activeInvoices.get(chatId);
      try {
        await this.client.sendMessage(msg.peerId, {
          message: `⚠️ Masih ada invoice aktif.\n\nInvoice : ${inv.orderId}\nNominal : Rp${inv.amount.toLocaleString("id")}\n\nSelesaikan invoice tersebut terlebih dahulu.`,
          replyTo: msg.id,
        });
      } catch (_) {}
      return;
    }

    const cfg = this.config;
    if (!cfg.API_KEY) {
      try { await this.client.sendMessage(msg.peerId, { message: "⚠️ API_KEY belum diisi di config.json.", replyTo: msg.id }); } catch (_) {}
      return;
    }

    // Generate order ID unik
    const orderId = `INV-${Date.now()}-${crypto.randomBytes(3).toString("hex").toUpperCase()}`;
    console.log(`[QRIS] Buat invoice ${orderId} Rp${amount}`);

    // Kirim loading message
    let loadingMsg;
    try {
      loadingMsg = await this.client.sendMessage(msg.peerId, { message: "⏳ Membuat QRIS..." });
    } catch (_) {}

    // Hit API create
    let apiRes;
    try {
      apiRes = await httpPost(
        cfg.API_CREATE_URL,
        { amount, order_id: orderId },
        { "x-api-key": cfg.API_KEY }
      );
    } catch (e) {
      console.log(`[QRIS ERR] API create: ${e.message}`);
      // Juga log full error kalau ada
      if (e.stack) console.log(e.stack.split('\n')[0]);
      try {
        await this.client.editMessage(msg.peerId, {
          message: loadingMsg?.id,
          text: `❌ Gagal menghubungi API pembayaran.\n${e.message}`,
        });
      } catch (_) {}
      return;
    }

    console.log(`[QRIS] API response:`, JSON.stringify(apiRes).slice(0, 300));
    if (!apiRes.success) {
      console.log(`[QRIS ERR] API response:`, JSON.stringify(apiRes));
      const errMsg = apiRes.message || apiRes.error || apiRes.msg || JSON.stringify(apiRes);
      try {
        await this.client.editMessage(msg.peerId, {
          message: loadingMsg?.id,
          text: `❌ API Error: ${errMsg}`,
        });
      } catch (_) {}
      return;
    }

    if (!apiRes.qr_image) {
      try {
        await this.client.editMessage(msg.peerId, {
          message: loadingMsg?.id,
          text: `❌ API tidak mengembalikan qr_image.`,
        });
      } catch (_) {}
      return;
    }

    // Decode Base64 → PNG
    const realOrderId     = apiRes.order_id || orderId;
    const realAmount      = apiRes.amount   || amount;
    const transactionId   = apiRes.transaction_id || orderId;
    const caption =
      `💳 *QRIS PAYMENT*\n\n` +
      `🧾 Invoice : \`${realOrderId}\`\n` +
      `💰 Nominal : Rp${realAmount.toLocaleString("id")}\n` +
      `📦 Status  : MENUNGGU PEMBAYARAN\n\n` +
      `Silakan scan QRIS di atas.\nPembayaran akan dicek otomatis.`;

    let tmpFile, qrisMsgId;
    try {
      // Decode base64
      const b64 = apiRes.qr_image.replace(/^data:image\/\w+;base64,/, "");
      const buf = Buffer.from(b64, "base64");
      if (!buf.length) throw new Error("Base64 kosong");
      tmpFile = path.join(os.tmpdir(), `qris_${orderId}.png`);
      fs.writeFileSync(tmpFile, buf);
    } catch (e) {
      console.log(`[QRIS ERR] Decode base64: ${e.message}`);
      try {
        await this.client.editMessage(msg.peerId, {
          message: loadingMsg?.id,
          text: `❌ Gagal decode gambar QRIS: ${e.message}`,
        });
      } catch (_) {}
      return;
    }

    // Hapus loading message, kirim foto
    try {
      if (loadingMsg) {
        await this.client.editMessage(msg.peerId, {
          message: loadingMsg.id,
          text: "📤 Mengirim QRIS...",
        });
      }
    } catch (_) {}

    try {
      const sentPhoto = await this.client.sendFile(msg.peerId, {
        file: tmpFile,
        caption,
        parseMode: "markdown",
        forceDocument: false,
      });
      qrisMsgId = sentPhoto.id;
      // Hapus loading msg
      if (loadingMsg) {
        try {
          await this.client.editMessage(msg.peerId, { message: loadingMsg.id, text: "✅" });
        } catch (_) {}
      }
      console.log(`[QRIS] Foto terkirim msgId=${qrisMsgId}`);
    } catch (e) {
      console.log(`[QRIS ERR] Kirim foto: ${e.message}`);
      try {
        await this.client.sendMessage(msg.peerId, {
          message: `❌ Gagal mengirim foto QRIS: ${e.message}`,
        });
      } catch (_) {}
      return;
    } finally {
      // Hapus file temp
      try { if (tmpFile && fs.existsSync(tmpFile)) fs.unlinkSync(tmpFile); } catch (_) {}
    }

    // Simpan invoice aktif
    const invoice = { orderId: realOrderId, transactionId, amount: realAmount, msgId: qrisMsgId, peerId: msg.peerId };
    this.activeInvoices.set(chatId, invoice);

    // Mulai monitoring pembayaran
    this.startMonitoring(chatId, invoice);
  }

  // ── Monitor pembayaran ──────────────────────────────
  startMonitoring(chatId, invoice) {
    const cfg     = this.config;
    const interval = cfg.STATUS_INTERVAL  || 5000;
    const timeout  = cfg.STATUS_TIMEOUT   || 1800000;
    const started  = Date.now();
    const PAID_STATUSES    = ["paid","success","successful","completed","settlement","settled"];
    const FAILED_STATUSES  = ["failed","cancelled","canceled","expired"];

    console.log(`[QRIS] Monitoring dimulai: ${invoice.orderId}`);

    const timer = setInterval(async () => {
      // Timeout
      if (Date.now() - started > timeout) {
        clearInterval(timer);
        this.activeInvoices.delete(chatId);
        console.log(`[QRIS] Timeout monitoring: ${invoice.orderId}`);
        try {
          await this.client.editMessage(invoice.peerId, {
            message: invoice.msgId,
            text:
              `❌ PEMBAYARAN GAGAL\n\n` +
              `Invoice : ${invoice.orderId}\n` +
              `Nominal : Rp${invoice.amount.toLocaleString("id")}\n` +
              `Status  : EXPIRED\n\n` +
              `Pembayaran tidak berhasil atau telah kedaluwarsa.`,
          });
        } catch (_) {}
        return;
      }

      // Cek status
      let statusRes;
      try {
        statusRes = await httpPost(
          cfg.API_STATUS_URL,
          { order_id: invoice.orderId },
          { "x-api-key": cfg.API_KEY }
        );
      } catch (e) {
        console.log(`[QRIS] Status check error: ${e.message}`);
        return; // retry di interval berikutnya
      }

      const status = (statusRes.status || "").toLowerCase();
      console.log(`[QRIS] Status ${invoice.orderId}: ${status}`);

      if (PAID_STATUSES.includes(status)) {
        clearInterval(timer);
        this.activeInvoices.delete(chatId);
        try {
          await this.client.editMessage(invoice.peerId, {
            message: invoice.msgId,
            text:
              `╭─「 PEMBAYARAN BERHASIL 」\n` +
              `│\n` +
              `│  Invoice : ${invoice.orderId}\n` +
              `│  Nominal : Rp${invoice.amount.toLocaleString("id")}\n` +
              `│  Status  : PAID\n` +
              `│\n` +
              `│  Pembayaran telah diterima\n` +
              `│  dan orderan telah selesai diproses.\n` +
              `│\n` +
              `╰─ Terima kasih telah melakukan pembayaran.`,
          });
        } catch (e) { console.log(`[QRIS] Edit paid err: ${e.message}`); }
        return;
      }

      if (FAILED_STATUSES.includes(status)) {
        clearInterval(timer);
        this.activeInvoices.delete(chatId);
        try {
          await this.client.editMessage(invoice.peerId, {
            message: invoice.msgId,
            text:
              `❌ PEMBAYARAN GAGAL\n\n` +
              `Invoice : ${invoice.orderId}\n` +
              `Nominal : Rp${invoice.amount.toLocaleString("id")}\n` +
              `Status  : ${status.toUpperCase()}\n\n` +
              `Pembayaran tidak berhasil atau telah kedaluwarsa.`,
          });
        } catch (e) { console.log(`[QRIS] Edit failed err: ${e.message}`); }
      }
    }, interval);

    // Simpan timer ke invoice biar bisa di-stop manual
    const inv = this.activeInvoices.get(chatId);
    if (inv) { inv.timer = timer; this.activeInvoices.set(chatId, inv); }
  }

  // ── .done ───────────────────────────────────────────
  async handleDone(event) {
    const msg    = event.message;
    const chatId = event.chatId?.toString() || msg.peerId?.toString();

    if (!this.activeInvoices.has(chatId)) {
      try {
        await this.client.sendMessage(msg.peerId, { message: "❌ Tidak ada invoice aktif.", replyTo: msg.id });
      } catch (_) {}
      return;
    }

    const inv = this.activeInvoices.get(chatId);
    if (inv.timer) clearInterval(inv.timer);
    this.activeInvoices.delete(chatId);
    console.log(`[QRIS] Done manual: ${inv.orderId}`);

    try {
      await this.client.editMessage(inv.peerId, {
        message: inv.msgId,
        text:
          `╭─「 ORDER SELESAI 」\n` +
          `│\n` +
          `│  Invoice : ${inv.orderId}\n` +
          `│  Status  : COMPLETED\n` +
          `│\n` +
          `│  Orderan dengan invoice\n` +
          `│  ${inv.orderId}\n` +
          `│  telah selesai diproses.\n` +
          `│\n` +
          `╰─ Terima kasih telah melakukan pembayaran.`,
      });
    } catch (e) { console.log(`[QRIS] Edit done err: ${e.message}`); }
  }

  // ── Panel kontrol (Saved Messages) ──────────────────
  async handlePanelCommand(event, text) {
    const msg   = event.message;
    const lower = text.toLowerCase();
    const reply = async t => {
      try { await this.client.sendMessage(msg.peerId, { message: t, parseMode: "markdown" }); }
      catch (e) { console.log(`[PANEL ERR] ${e.message}`); }
    };

    this.reload();
    const cfg = this.config;

    if (lower === ".menu")                      { await reply(buildMenu(cfg)); return; }
    if (lower === ".status")                    { await reply(buildStatus(cfg)); return; }
    if (lower === ".ar on")                     { cfg.autoReply = true;  saveConfig(cfg); this.reload(); await reply("✅ AR Channel *dinyalakan*."); return; }
    if (lower === ".ar off")                    { cfg.autoReply = false; saveConfig(cfg); this.reload(); await reply("🔴 AR Channel *dimatikan*."); return; }
    if (lower === ".ar pm on")                  { cfg.pmReply = true;  saveConfig(cfg); this.reload(); await reply("✅ AR PM *dinyalakan*."); return; }
    if (lower === ".ar pm off")                 { cfg.pmReply = false; saveConfig(cfg); this.reload(); await reply("🔴 AR PM *dimatikan*."); return; }
    if (lower === ".bc stop")                   { cfg.broadcast = null; saveConfig(cfg); this.reload(); this.syncBroadcast(); await reply("⏹ Broadcast dihentikan."); return; }
    if (lower === ".kw list") {
      if (!cfg.keywords.length) { await reply("🔑 Belum ada keyword."); return; }
      let t = `🔑 *Keyword* (${cfg.keywords.length})\n\n`;
      cfg.keywords.forEach((kw, i) => {
        const rep = kw.reply.length > 50 ? kw.reply.slice(0, 47) + "..." : kw.reply;
        t += `${i+1}. ${kw.aliases.join(", ")}\n   ↪ ${rep}\n\n`;
      });
      await reply(t.trim()); return;
    }
    if (lower === ".bl list") {
      if (!cfg.blacklist.length) { await reply("🚫 Blacklist kosong."); return; }
      let t = `🚫 *Blacklist* (${cfg.blacklist.length})\n\n`;
      cfg.blacklist.forEach((w, i) => { t += `${i+1}. ${w}\n`; });
      await reply(t.trim()); return;
    }

    // .pm msg {teks}
    if (lower.startsWith(".pm msg ")) {
      const newMsg = text.slice(8).trim();
      if (!newMsg) { await reply("⚠️ Pesan tidak boleh kosong."); return; }
      cfg.pm.message = newMsg; saveConfig(cfg); this.reload();
      await reply(`✅ Pesan PM diperbarui:\n\n${newMsg}`); return;
    }

    // .pm cd {detik}
    if (lower.startsWith(".pm cd ")) {
      const n = parseInt(text.slice(7).trim(), 10);
      if (isNaN(n) || n < 0) { await reply("⚠️ Harus angka ≥ 0."); return; }
      cfg.pm.cooldown_seconds = n; saveConfig(cfg); this.reload();
      await reply(`✅ Cooldown PM: ${n > 0 ? n + "s / user" : "off"}`); return;
    }

    // .kw add {alias,..} | {balas}
    if (lower.startsWith(".kw add ")) {
      const content = text.slice(8).trim();
      const sep     = content.indexOf("|");
      if (sep === -1) { await reply("⚠️ Format: `.kw add alias1,alias2 | balasan`"); return; }
      const aliases = content.slice(0, sep).trim().split(",").map(a => a.trim().toLowerCase()).filter(Boolean);
      const rep     = content.slice(sep + 1).trim();
      if (!aliases.length || !rep) { await reply("⚠️ Alias dan balasan tidak boleh kosong."); return; }
      cfg.keywords.push({ aliases, reply: rep }); saveConfig(cfg); this.reload();
      await reply(`✅ Keyword ditambahkan!\n${aliases.join(", ")} → ${rep}`); return;
    }

    // .kw del {n}
    if (lower.startsWith(".kw del ")) {
      const n = parseInt(text.slice(8).trim(), 10);
      if (isNaN(n) || n < 1 || n > cfg.keywords.length) { await reply(`⚠️ Nomor tidak valid (1-${cfg.keywords.length}).`); return; }
      const removed = cfg.keywords.splice(n - 1, 1)[0]; saveConfig(cfg); this.reload();
      await reply(`🗑 Keyword #${n} dihapus: ${removed.aliases.join(", ")}`); return;
    }

    // .bl add {kata,..}
    if (lower.startsWith(".bl add ")) {
      const words = text.slice(8).trim().split(",").map(w => w.trim().toLowerCase()).filter(Boolean);
      const added = words.filter(w => !cfg.blacklist.includes(w));
      added.forEach(w => cfg.blacklist.push(w)); saveConfig(cfg); this.reload();
      await reply(added.length ? `🚫 Ditambahkan: ${added.join(", ")}` : "ℹ️ Semua kata sudah ada."); return;
    }

    // .bl del {n}
    if (lower.startsWith(".bl del ")) {
      const n = parseInt(text.slice(8).trim(), 10);
      if (isNaN(n) || n < 1 || n > cfg.blacklist.length) { await reply(`⚠️ Nomor tidak valid (1-${cfg.blacklist.length}).`); return; }
      const removed = cfg.blacklist.splice(n - 1, 1)[0]; saveConfig(cfg); this.reload();
      await reply(`✅ "${removed}" dihapus dari blacklist.`); return;
    }

    // .bc {pesan} | {detik?}
    if (lower.startsWith(".bc ")) {
      const body  = text.slice(4).trim();
      const parts = body.split("|");
      const bcText = parts[0].trim();
      const sec    = parts[1] ? parseInt(parts[1].trim(), 10) : null;
      if (!bcText) { await reply("⚠️ Pesan tidak boleh kosong."); return; }
      if (sec !== null && (isNaN(sec) || sec < 10)) { await reply("⚠️ Interval minimal 10 detik."); return; }
      cfg.broadcast = sec ? { text: bcText, intervalSec: sec } : null;
      saveConfig(cfg); this.reload(); this.syncBroadcast();
      if (sec) {
        await reply(`🔁 Broadcast tiap ${sec}s dimulai.`);
      } else {
        await reply("📤 Mengirim broadcast...");
        await this.doBroadcast(bcText);
        await reply("✅ Broadcast selesai.");
      }
      return;
    }
  }

  // ── Start ───────────────────────────────────────────
  async start() {
    const ss = loadSession(this.config.session_name);
    this.client = new TelegramClient(
      ss ? new StringSession(ss) : new StringSession(),
      this.config.api_id, this.config.api_hash, { connectionRetries: 5 }
    );

    await this.client.start({
      phoneNumber: async () => this.config.phone,
      password:    async () => this.config.password || "",
      phoneCode:   async () => {
        const rl   = createRL();
        const code = await question(rl, "Masukkan OTP: ");
        rl.close();
        return code;
      },
      onError: e => console.log("[LOGIN ERR]", e.message),
    });

    saveSession(this.config.session_name, this.client.session.save());
    const me  = await this.client.getMe();
    this.myId = me.id;
    console.log(`[OK] Login: ${me.firstName} (@${me.username || "-"})`);
    console.log(`[OK] Buka Saved Messages, ketik !menu untuk panel kontrol`);

    this.client.addEventHandler(this.handleMessage.bind(this), new NewMessage({}));
    this.syncBroadcast();
    this.startPolling().catch(e => { console.error("[POLL FATAL]", e.message); process.exit(1); });

    console.log("[RUNNING] Userbot aktif.\n");
    await new Promise(() => {});
  }
}

// ──────────────────────────────────────────────────────────
// MAIN
// ──────────────────────────────────────────────────────────

async function main() {
  if (!fs.existsSync(CONFIG_PATH)) await runSetupWizard();
  const bot = new Userbot();
  await bot.start();
}

main().catch(e => { console.error("[FATAL]", e); process.exit(1); });
